export default function BlogContainer({ children }) {
  return <div className="container mx-auto px-5">{children}</div>
}
