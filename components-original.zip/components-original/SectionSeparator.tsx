export default function SectionSeparator() {
  return <hr className="mb-24 mt-28 border-accent-2" />
}
